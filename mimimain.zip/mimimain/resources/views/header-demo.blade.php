@extends('layouts.app')

@section('title', 'Demo Header')

@section('content')
  {{-- Phần này chỉ để bạn nhìn thấy header --}}
  <div style="height:200px; background:#f0f0f0; display:flex; align-items:center; justify-content:center;">
    <p class="text-secondary">Đây là khu vực nội dung trống, chỉ để test header 😊</p>
  </div>
@endsection
