@extends('layouts.app')

@section('title','Giỏ hàng')

@section('content')
<div class="container py-5">
  <h1 class="mb-4">Giỏ hàng của bạn</h1>

  @php $items = session('cart', []); $total = 0; @endphp

  @if(empty($items))
    <div class="alert alert-info">Giỏ hàng trống.</div>
  @else
    <table class="table">
      <thead>
        <tr>
          <th>Sản phẩm</th>
          <th>Đơn giá</th>
          <th>Số lượng</th>
          <th>Thành tiền</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        @foreach($items as $item)
          @php
            $sub = $item['price'] * $item['quantity'];
            $total += $sub;
          @endphp
          <tr>
            <td>
              <img src="{{ asset('storage/'.$item['img']) }}"
                   style="width:50px;height:50px;object-fit:cover;"
                   class="me-2">
              {{ $item['name'] }}
            </td>
            <td>{{ number_format($item['price'],0,',','.') }}₫</td>
            <td>
              <form action="{{ route('cart.decrement', $item['id']) }}"
                    method="POST" class="d-inline">
                @csrf
                <button class="btn btn-sm btn-outline-secondary">−</button>
              </form>
              {{ $item['quantity'] }}
              <form action="{{ route('cart.add', $item['id']) }}"
                    method="POST" class="d-inline">
                @csrf
                <button class="btn btn-sm btn-outline-secondary">+</button>
              </form>
            </td>
            <td>{{ number_format($sub,0,',','.') }}₫</td>
            <td>
              <form action="{{ route('cart.remove', $item['id']) }}"
                    method="POST">
                @csrf
                <button class="btn btn-sm btn-outline-danger">Xóa</button>
              </form>
            </td>
          </tr>
        @endforeach
        <tr>
          <td colspan="3" class="text-end"><strong>Tổng cộng:</strong></td>
          <td colspan="2"><strong>{{ number_format($total,0,',','.') }}₫</strong></td>
        </tr>
      </tbody>
    </table>

    <a href="{{ route('cart.checkout') }}" class="btn btn-success">
      Thanh toán
    </a>
  @endif
</div>
@endsection
