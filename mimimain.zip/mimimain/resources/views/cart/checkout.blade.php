@extends('layouts.app')

@section('title','Thanh toán')

@section('content')
<div class="container py-5">
  <h1 class="mb-4">Thanh toán</h1>
  <p>Chức năng thanh toán sẽ được triển khai sau.</p>
</div>
@endsection
