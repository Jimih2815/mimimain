@extends('layouts.app')

@section('title','Tất cả sản phẩm')
@section('content')
  <div class="container py-4">
    <h1>Tất cả sản phẩm</h1>
    {{-- Sau này loop $products vào đây --}}
  </div>
@endsection
