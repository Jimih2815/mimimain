<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SearchController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Trang chủ
Route::get('/', [HomeController::class, 'index'])
     ->name('home');

// Demo header (nếu cần)
Route::get('/header-demo', fn() => view('header-demo'))
     ->name('header.demo');

// Tìm kiếm
Route::get('/search', [SearchController::class, 'index'])
     ->name('search');

// Danh sách sản phẩm
Route::get('/products', [ProductController::class, 'index'])
     ->name('products.index');

// Chi tiết 1 biến thể (classification)
Route::get('/products/{id}', [ProductController::class, 'show'])
     ->name('products.show');
