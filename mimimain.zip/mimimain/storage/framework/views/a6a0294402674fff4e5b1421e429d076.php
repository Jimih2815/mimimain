<?php $__env->startSection('title', 'Tất cả sản phẩm'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <h1 class="mb-4">Tất cả sản phẩm</h1>

  <?php if($items->isEmpty()): ?>
    <div class="alert alert-info">Chưa có sản phẩm nào.</div>
  <?php else: ?>
    <div class="row g-4">
      <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $base   = $item->product->base_price;
          $extras = $item->options->pluck('extra_price')->all();
          if (empty($extras)) {
            $min = $max = $base;
          } else {
            $min = $base + min($extras);
            $max = $base + max($extras);
          }
        ?>

        <div class="col-sm-6 col-md-4 col-lg-3">
          <div class="card h-100">
            <a href="<?php echo e(route('products.show', $item->id)); ?>">
              <img
                src="<?php echo e(asset('storage/'.$item->img)); ?>"
                class="card-img-top"
                style="height:200px; object-fit:cover;"
                alt="<?php echo e($item->name); ?>"
              >
            </a>
            <div class="card-body d-flex flex-column">
              <h5 class="card-title">
                <a href="<?php echo e(route('products.show', $item->id)); ?>"
                   class="text-dark text-decoration-none">
                  <?php echo e($item->name); ?>

                </a>
              </h5>
              <p class="card-text mt-auto fw-bold text-primary">
                <?php echo e(number_format($min,0,',','.')); ?>₫
                <?php if($min !== $max): ?>
                  &ndash; <?php echo e(number_format($max,0,',','.')); ?>₫
                <?php endif; ?>
              </p>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mimimain\resources\views/products/index.blade.php ENDPATH**/ ?>