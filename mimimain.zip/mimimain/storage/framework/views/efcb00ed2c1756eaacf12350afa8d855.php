<header>
  
  <div class="header-top d-flex align-items-center justify-content-between px-4 py-2">
    <a href="/" class="d-flex align-items-center">
      <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" height="50">
    </a>
    <div class="input-group mx-4 flex-grow-1">
        <form action="<?php echo e(route('search')); ?>" method="GET" class="input-group mx-4 flex-grow-1">
            <input 
                type="text" 
                name="q" 
                class="form-control" 
                placeholder="Tìm kiếm..." 
                value="<?php echo e(request('q')); ?>"
            >
            <button class="btn btn-primary">
                <i class="bi bi-search"></i>
            </button>
        </form>
    </div>
    <div class="contact-info text-primary">
      <i class="fas fa-phone-alt me-1"></i>0123 456 789
    </div>
  </div>

  
  <nav class="header-nav bg-light">
    <div class="container">
      <ul class="nav justify-content-center">
        <?php $__currentLoopData = ['ĐÈN NGỦ','HOA GẤU BÔNG','GẤU BÔNG','SET QUÀ TẶNG','KHÁC']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item dropdown position-static">
          <a class="nav-link" href="#" data-bs-toggle="dropdown"><?php echo e($cat); ?></a>
          <div class="dropdown-menu w-100 mega-menu p-4">
            <div class="container">
              
              <div class="row mb-3">
                <?php for($i=1; $i<=4; $i++): ?>
                <div class="col-md-3 text-center">
                  <div class="mega-header-box py-3 rounded mb-2">
                    <!-- bạn đổi thành dữ liệu dynamic sau -->
                    <?php echo e($cat); ?> Header <?php echo e($i); ?>

                  </div>
                </div>
                <?php endfor; ?>
              </div>
              
              <div class="row">
                <?php for($i=1; $i<=4; $i++): ?>
                <div class="col-md-3">
                  <ul class="list-unstyled mega-list">
                    
                    <li><a href="#">Liên kết <?php echo e($i); ?>A</a></li>
                    <li><a href="#">Liên kết <?php echo e($i); ?>B</a></li>
                    <li><a href="#">Liên kết <?php echo e($i); ?>C</a></li>
                  </ul>
                </div>
                <?php endfor; ?>
              </div>
            </div>
          </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('products.index')); ?>">TẤT CẢ SẢN PHẨM</a>
        </li>
      </ul>
    </div>
  </nav>
</header>
<?php /**PATH C:\xampp\htdocs\mimimain\resources\views/partials/header.blade.php ENDPATH**/ ?>