

<?php $__env->startSection('title','Giỏ hàng'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <h1 class="mb-4">Giỏ hàng của bạn</h1>

  <?php $items = session('cart', []); $total = 0; ?>

  <?php if(empty($items)): ?>
    <div class="alert alert-info">Giỏ hàng trống.</div>
  <?php else: ?>
    <table class="table">
      <thead>
        <tr>
          <th>Sản phẩm</th>
          <th>Đơn giá</th>
          <th>Số lượng</th>
          <th>Thành tiền</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $sub = $item['price'] * $item['quantity'];
            $total += $sub;
          ?>
          <tr>
            <td>
              <img src="<?php echo e(asset('storage/'.$item['img'])); ?>"
                   style="width:50px;height:50px;object-fit:cover;"
                   class="me-2">
              <?php echo e($item['name']); ?>

            </td>
            <td><?php echo e(number_format($item['price'],0,',','.')); ?>₫</td>
            <td>
              <form action="<?php echo e(route('cart.decrement', $item['id'])); ?>"
                    method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <button class="btn btn-sm btn-outline-secondary">−</button>
              </form>
              <?php echo e($item['quantity']); ?>

              <form action="<?php echo e(route('cart.add', $item['id'])); ?>"
                    method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <button class="btn btn-sm btn-outline-secondary">+</button>
              </form>
            </td>
            <td><?php echo e(number_format($sub,0,',','.')); ?>₫</td>
            <td>
              <form action="<?php echo e(route('cart.remove', $item['id'])); ?>"
                    method="POST">
                <?php echo csrf_field(); ?>
                <button class="btn btn-sm btn-outline-danger">Xóa</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td colspan="3" class="text-end"><strong>Tổng cộng:</strong></td>
          <td colspan="2"><strong><?php echo e(number_format($total,0,',','.')); ?>₫</strong></td>
        </tr>
      </tbody>
    </table>

    <a href="<?php echo e(route('cart.checkout')); ?>" class="btn btn-success">
      Thanh toán
    </a>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mimimain\resources\views/cart/index.blade.php ENDPATH**/ ?>