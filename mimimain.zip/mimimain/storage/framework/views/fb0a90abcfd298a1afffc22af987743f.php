

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h2 class="mb-4">🛒 Giỏ hàng của bạn</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(count($cart) > 0): ?>
        <table class="table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th>Ảnh</th>
                    <th>Tên sản phẩm</th>
                    <th>Đơn giá</th>
                    <th>Số lượng</th>
                    <th>Thành tiền</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php if($item['image']): ?>
                            <img src="<?php echo e($item['image']); ?>" alt="" width="60">
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($item['name']); ?></td>
                    <td><?php echo e(number_format($item['price'], 0, ',', '.')); ?>₫</td>
                    <td><?php echo e($item['quantity']); ?></td>
                    <td><?php echo e(number_format($item['price'] * $item['quantity'], 0, ',', '.')); ?>₫</td>
                    <td>
                        <form action="<?php echo e(route('cart.remove', ['id' => $id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-danger btn-sm">Xóa</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="text-right">
            <h4>Tổng cộng: <strong><?php echo e(number_format($total, 0, ',', '.')); ?>₫</strong></h4>
        </div>
    <?php else: ?>
        <p>Giỏ hàng trống. Hãy thêm sản phẩm nào! 😊</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mimimain\resources\views/cart/index.blade.php ENDPATH**/ ?>