<?php $__env->startSection('title', 'Kết quả tìm kiếm'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <h2 class="mb-4">Kết quả tìm kiếm cho: '<?php echo e($q); ?>'</h2>

  <?php if(trim($q) === '' || $results->isEmpty()): ?>
    <div class="alert alert-warning">
      Không tìm thấy kết quả phù hợp.
    </div>
  <?php else: ?>
    <div class="list-group">
      <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a
          href="<?php echo e(route('products.show', $item->id)); ?>"
          class="list-group-item list-group-item-action"
        >
          <?php echo e($item->name); ?>

        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mimimain\resources\views/search.blade.php ENDPATH**/ ?>