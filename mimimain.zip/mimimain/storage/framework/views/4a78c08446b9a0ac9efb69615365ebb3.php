<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <h1 class="mb-4"><?php echo e($product->name); ?></h1>
  <p>Chọn màu:</p>

  <?php if($product->classifications->isEmpty()): ?>
    <div class="alert alert-info">Chưa có lựa chọn màu nào.</div>
  <?php else: ?>
    <div class="row g-3">
      <?php $__currentLoopData = $product->classifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-auto text-center">
          <a href="<?php echo e(route('products.show', $variant->id)); ?>"
             class="text-decoration-none">
            <img
              src="<?php echo e(asset('storage/'.$variant->img)); ?>"
              class="img-thumbnail mb-2"
              style="width:100px; height:100px; object-fit:cover;"
              alt="<?php echo e($variant->name); ?>"
            >
            <div><?php echo e($variant->name); ?></div>
          </a>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php endif; ?>

  <p class="mt-4">
    <a href="<?php echo e(url()->previous()); ?>">&larr; Quay lại</a>
  </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mimimain\resources\views/products/detail.blade.php ENDPATH**/ ?>