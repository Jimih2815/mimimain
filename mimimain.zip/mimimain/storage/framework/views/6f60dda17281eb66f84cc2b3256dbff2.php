

<?php $__env->startSection('title', $classification->name); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <div class="row">
    
    <div class="col-md-6">
      <div class="d-flex mb-3">
        <div class="me-3" style="width:80px;">
          <?php $__currentLoopData = $subImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img
              src="<?php echo e(asset('storage/'.$img)); ?>"
              class="img-fluid mb-2 thumbnail"
              style="cursor:pointer;"
              onclick="document.getElementById('main-img').src=this.src"
            >
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <img
          id="main-img"
          src="<?php echo e(asset('storage/'.$mainImage)); ?>"
          class="img-fluid"
          style="max-height:400px; object-fit:cover;"
        >
      </div>

      
      <div class="mb-4">
        <h5>Chọn kích cỡ:</h5>
        <div class="btn-group" role="group">
          <?php $__currentLoopData = $sizeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button
              type="button"
              class="btn btn-outline-secondary size-option"
              data-price="<?php echo e($opt->extra_price); ?>"
            >
              <?php echo e($opt->name); ?>

            </button>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>

    
    <div class="col-md-6">
      <h2 class="mb-3"><?php echo e($classification->name); ?></h2>
      <?php
        $base    = $classification->product->base_price;
        $initial = $base + ($sizeOptions->first()->extra_price ?? 0);
      ?>
      <p id="price" class="h4 text-primary"><?php echo e(number_format($initial,0,',','.')); ?>₫</p>

      
      <button class="btn btn-primary w-100 mb-2">Thêm giỏ hàng</button>

      
      <button class="btn btn-outline-secondary w-100">
        ❤️ Yêu thích
      </button>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  (function(){
    const base = <?php echo e($classification->product->base_price); ?>;
    document.querySelectorAll('.size-option').forEach(btn=>{
      btn.addEventListener('click',()=>{
        document.querySelectorAll('.size-option').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        const extra = parseInt(btn.dataset.price);
        document.getElementById('price').innerText =
          new Intl.NumberFormat('vi-VN').format(base+extra)+'₫';
      });
    });
  })();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mimimain\resources\views/products/show.blade.php ENDPATH**/ ?>