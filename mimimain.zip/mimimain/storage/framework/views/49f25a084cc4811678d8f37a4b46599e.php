<?php $__env->startSection('title', $category->name); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <h1 class="mb-4">Danh mục: <?php echo e($category->name); ?></h1>
  <p>Chọn phân mục con:</p>

  <?php if($children->isEmpty()): ?>
    <div class="alert alert-info">Không có phân mục con.</div>
  <?php else: ?>
    <div class="list-group">
      <?php $__currentLoopData = $children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('categories.show', $sub->id)); ?>"
           class="list-group-item list-group-item-action">
          <?php echo e($sub->name); ?>

        </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  <?php endif; ?>

  <p class="mt-3">
    <a href="<?php echo e(route('categories.index')); ?>">&larr; Quay về danh mục chính</a>
  </p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mimimain\resources\views/categories/children.blade.php ENDPATH**/ ?>