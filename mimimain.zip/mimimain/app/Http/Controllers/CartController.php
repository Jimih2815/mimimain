<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Classification;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    /**
     * Hiển thị trang giỏ hàng
     */
    public function index()
    {
        $items = session('cart', []);
        return view('cart.index', compact('items'));
    }

    /**
     * Thêm 1 classification vào giỏ (guest hoặc user)
     */
    public function add($id)
    {
        $variant = Classification::with('product')->findOrFail($id);

        // session cart: [variant_id => [...]]
        $cart = session('cart', []);

        if(isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                'id'       => $id,
                'name'     => $variant->product->name.' – '.$variant->name,
                'price'    => $variant->product->base_price + ($variant->options->first()->extra_price ?? 0),
                'img'      => $variant->img,
                'quantity' => 1,
            ];
        }

        session(['cart' => $cart]);

        return back()->with('success','Đã thêm vào giỏ hàng');
    }

    /**
     * Giảm số lượng (hoặc xóa nếu =0)
     */
    public function decrement($id)
    {
        $cart = session('cart', []);
        if(isset($cart[$id])) {
            $cart[$id]['quantity']--;
            if($cart[$id]['quantity'] <= 0) {
                unset($cart[$id]);
            }
            session(['cart' => $cart]);
        }
        return back();
    }

    /**
     * Xóa hẳn item
     */
    public function remove($id)
    {
        $cart = session('cart', []);
        if(isset($cart[$id])) {
            unset($cart[$id]);
            session(['cart' => $cart]);
        }
        return back();
    }

    /**
     * Trang thanh toán (chỉ cho user đã login)
     */
    public function checkout()
    {
        $this->middleware('auth');
        $items = session('cart', []);
        return view('cart.checkout', compact('items'));
    }
}
