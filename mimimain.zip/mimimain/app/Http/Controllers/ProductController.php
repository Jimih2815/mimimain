<?php

namespace App\Http\Controllers;

use App\Models\Product;           // ← thêm dòng này
use App\Models\Classification;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    // Trang "Tất cả sản phẩm"
    public function index()
    {
        // Lấy tất cả products, kèm variants + options để tính giá
        $items = Product::with('classifications.options')->get();

        // DEBUG tạm (nếu muốn kiểm tra)
        // dd($items->count(), $items->toArray());

        return view('products.index', compact('items'));
    }

    // Trang chi tiết (classification_id)
    public function show($id)
    {
        $classification = Classification::with([
            'product',
            'product.classifications',
            'options',
        ])->findOrFail($id);

        $product       = $classification->product;
        $subImages     = $product->classifications->pluck('img')->filter()->toArray();
        $mainImage     = $classification->img;
        $colorVariants = $product->classifications;
        $sizeOptions   = $classification->options;

        return view('products.show', compact(
            'product','classification','subImages','mainImage','colorVariants','sizeOptions'
        ));
    }
}
