

<?php $__env->startSection('title','Thanh Toán'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <h2 class="mb-4">Thanh toán đơn hàng</h2>

  
  <div class="mb-5">
    <h4>Sản phẩm của bạn</h4>
    <table class="table">
      <thead>
        <tr>
          <th>Ảnh</th>
          <th>Sản phẩm</th>
          <th>Đơn giá</th>
          <th>Số lượng</th>
          <th>Thành tiền</th>
        </tr>
      </thead>
      <tbody>
        <?php $grand = 0; ?>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $line   = $item['price'] * $item['quantity'];
            $grand += $line;
          ?>
          <tr>
            <td>
              <?php if($item['image']): ?>
                <img src="<?php echo e($item['image']); ?>" width="60" alt="">
              <?php endif; ?>
            </td>
            <td><?php echo e($item['name']); ?></td>
            <td><?php echo e(number_format($item['price'],0,',','.')); ?>₫</td>
            <td><?php echo e($item['quantity']); ?></td>
            <td><?php echo e(number_format($line,0,',','.')); ?>₫</td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <div class="text-end">
      <h5>Tổng: <strong><?php echo e(number_format($grand,0,',','.')); ?>₫</strong></h5>
    </div>
  </div>

  
  <form id="checkoutForm" action="<?php echo e(route('checkout.process')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    
    <h4 class="mb-3">Thông tin người nhận</h4>
    <div class="row mb-4">
      <div class="col-md-6 mb-3">
        <label class="form-label">Họ tên</label>
        <input type="text" name="name" class="form-control" required>
      </div>
      <div class="col-md-6 mb-3">
        <label class="form-label">Số điện thoại</label>
        <input type="text" name="phone" class="form-control" required>
      </div>
      <div class="col-12 mb-3">
        <label class="form-label">Địa chỉ</label>
        <textarea name="address" class="form-control" rows="2" required></textarea>
      </div>
      <div class="col-12 mb-4">
        <label class="form-label">Ghi chú</label>
        <textarea name="note" class="form-control" rows="2"></textarea>
      </div>
    </div>

    
    <h4 class="mb-3">Phương thức thanh toán</h4>
    <div class="form-check mb-2">
      <input
        class="form-check-input"
        type="radio"
        name="payment"
        id="cod"
        value="cod"
        checked
      >
      <label class="form-check-label" for="cod">COD (Thanh toán khi nhận hàng)</label>
    </div>
    <div class="form-check mb-4">
      <input
        class="form-check-input"
        type="radio"
        name="payment"
        id="bank"
        value="bank"
      >
      <label class="form-check-label" for="bank">Chuyển khoản ngân hàng</label>
    </div>

    
    <button type="submit" class="btn btn-success mb-4" id="confirmCod">Xác nhận thanh toán</button>

    
    <div id="bankSection" style="display:none;">
      <h5>Chuyển khoản ngân hàng</h5>

      
      <img src="<?php echo e($qrUrl); ?>" alt="QR Code" class="mb-3">

      <p>
        Chủ TK: <strong>PHAN THAO NGUYEN</strong><br>
        Số TK: <strong>19032724004016</strong><br>
        Ngân hàng: <strong>Techcombank</strong><br>
        Số tiền: <strong><?php echo e(number_format($grand,0,',','.')); ?>₫</strong>
      </p>
      <p class="text-warning">
        Bạn chuyển khoản thành công sau đó ấn 
        <strong>"Xác nhận đã chuyển khoản"</strong> nha
      </p>
      <button type="button" id="confirmBank" class="btn btn-primary">
        Xác nhận đã chuyển khoản
      </button>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    const codRadio    = document.getElementById('cod');
    const bankRadio   = document.getElementById('bank');
    const bankSection = document.getElementById('bankSection');
    const confirmCod  = document.getElementById('confirmCod');
    const confirmBank = document.getElementById('confirmBank');
    const form        = document.getElementById('checkoutForm');

    // Toggle giữa COD và Bank
    codRadio.addEventListener('change', () => {
      bankSection.style.display = 'none';
      confirmCod.style.display   = 'inline-block';
    });
    bankRadio.addEventListener('change', () => {
      bankSection.style.display = 'block';
      confirmCod.style.display   = 'none';
    });

    // Khi bấm “Xác nhận đã chuyển khoản” thì submit form
    confirmBank.addEventListener('click', () => form.submit());
  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mimimain\resources\views/checkout/show.blade.php ENDPATH**/ ?>