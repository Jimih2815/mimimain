

<?php $__env->startSection('title','Giỏ hàng'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <h2>Giỏ hàng</h2>

  <?php if(session('error')): ?>
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
  <?php elseif(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
  <?php endif; ?>

  <form action="<?php echo e(route('checkout.show')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <?php if(count($cart) > 0): ?>
      <table class="table">
        <thead>
          <tr>
            <th><input type="checkbox" id="checkAll"></th>
            <th>Ảnh</th>
            <th>Sản phẩm</th>
            <th>Đơn giá</th>
            <th>Số lượng</th>
            <th>Thành tiền</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <input type="checkbox" name="selected_ids[]" value="<?php echo e($id); ?>" class="rowCheck">
              </td>
              <td><?php if($item['image']): ?><img src="<?php echo e($item['image']); ?>" width="60"><?php endif; ?></td>
              <td><?php echo e($item['name']); ?></td>
              <td><?php echo e(number_format($item['price'],0,',','.')); ?>₫</td>
              <td><?php echo e($item['quantity']); ?></td>
              <td><?php echo e(number_format($item['price'] * $item['quantity'],0,',','.')); ?>₫</td>
              <td>
                <form action="<?php echo e(route('cart.remove',['id'=>$id])); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-danger btn-sm">Xóa</button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      <div class="text-end mb-4">
        <h4>Tổng cộng: <?php echo e(number_format($total,0,',','.')); ?>₫</h4>
      </div>

      <button class="btn btn-primary">Thanh toán</button>
    <?php else: ?>
      <p>Giỏ hàng trống!</p>
    <?php endif; ?>
  </form>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
  // Check/Uncheck all
  document.getElementById('checkAll').addEventListener('change', function(){
    document.querySelectorAll('.rowCheck').forEach(ch=> ch.checked = this.checked);
  });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mimimain\resources\views/cart/index.blade.php ENDPATH**/ ?>