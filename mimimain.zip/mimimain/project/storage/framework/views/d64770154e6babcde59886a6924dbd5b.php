<?php $__env->startSection('title','Danh mục sản phẩm'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

  
  <ul class="nav nav-pills mb-4" id="categoryTabs" role="tablist">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="nav-item" role="presentation">
        <button
          class="nav-link <?php echo e($i === 0 ? 'active' : ''); ?>"
          id="tab-<?php echo e($cat->slug); ?>"
          data-bs-toggle="pill"
          data-bs-target="#content-<?php echo e($cat->slug); ?>"
          type="button"
          role="tab"
          aria-controls="content-<?php echo e($cat->slug); ?>"
          aria-selected="<?php echo e($i === 0 ? 'true' : 'false'); ?>"
        >
          <?php echo e($cat->name); ?>

        </button>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>

  
  <div class="tab-content" id="categoryTabsContent">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div
        class="tab-pane fade <?php echo e($i === 0 ? 'show active' : ''); ?>"
        id="content-<?php echo e($cat->slug); ?>"
        role="tabpanel"
        aria-labelledby="tab-<?php echo e($cat->slug); ?>"
      >
        <?php if($cat->products->isEmpty()): ?>
          <p class="text-muted">Chưa có sản phẩm cho mục này.</p>
        <?php else: ?>
          <div class="row">
            <?php $__currentLoopData = $cat->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-3 mb-4">
                <div class="card h-100">
                  <img src="<?php echo e($product->img); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
                  <div class="card-body d-flex flex-column">
                    <h5 class="card-title"><?php echo e($product->name); ?></h5>
                    <p class="fw-bold mt-auto"><?php echo e(number_format($product->base_price,0,',','.')); ?>₫</p>
                    <a href="<?php echo e(route('products.show',['slug'=>$product->slug])); ?>"
                       class="btn btn-sm btn-primary mt-2">
                      Xem chi tiết
                    </a>
                  </div>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mimimain\resources\views/categories/index.blade.php ENDPATH**/ ?>