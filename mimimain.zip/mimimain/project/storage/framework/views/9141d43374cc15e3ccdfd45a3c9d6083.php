<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?php echo e(config('app.name','MimiMain')); ?> – <?php echo $__env->yieldContent('title'); ?></title>
  <?php echo app('Illuminate\Foundation\Vite')([
  'resources/css/app.css',
  'resources/css/header.css',   
  'resources/css/swiper.css',   
  'resources/js/app.js',
]); ?>
</head>
<body class="antialiased">
  <div class="container py-5">
    <?php echo $__env->yieldContent('content'); ?>
  </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\mimimain\resources\views/layouts/guest.blade.php ENDPATH**/ ?>