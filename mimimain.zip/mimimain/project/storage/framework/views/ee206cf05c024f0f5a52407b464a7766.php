


<?php $__env->startSection('title','Admin — Quản lý Mega‑Menu Header'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <h2 class="mb-4">Quản lý Mega‑Menu Header</h2>

  
  <ul class="nav nav-tabs mb-3" id="catTab" role="tablist">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="nav-item" role="presentation">
        <button
          class="nav-link <?php echo e($i===0?'active':''); ?>"
          id="cat-<?php echo e($cat->id); ?>-tab"
          data-bs-toggle="tab"
          data-bs-target="#cat-<?php echo e($cat->id); ?>"
          type="button"
          role="tab"
          aria-controls="cat-<?php echo e($cat->id); ?>"
          aria-selected="<?php echo e($i===0?'true':'false'); ?>"
        >
          <?php echo e($cat->name); ?>

        </button>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>

  <div class="tab-content" id="catTabContent">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div
        class="tab-pane fade <?php echo e($i===0?'show active':''); ?>"
        id="cat-<?php echo e($cat->id); ?>"
        role="tabpanel"
        aria-labelledby="cat-<?php echo e($cat->id); ?>-tab"
      >
        <h4 class="mb-3">Category: <?php echo e($cat->name); ?></h4>

        
        <ul class="list-group mb-4">
          <?php $__currentLoopData = $cat->headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item">

              
              <form
                action="<?php echo e(route('admin.headers.update', $header)); ?>"
                method="POST"
                class="d-flex gap-2 align-items-center mb-3"
              >
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                <input
                  type="text"
                  name="title"
                  value="<?php echo e($header->title); ?>"
                  class="form-control form-control-sm w-25"
                  placeholder="Tiêu đề Header"
                >
                <input
                  type="number"
                  name="sort_order"
                  value="<?php echo e($header->sort_order); ?>"
                  class="form-control form-control-sm w-10"
                  step="1"
                  placeholder="Thứ tự"
                >
                <button class="btn btn-success btn-sm">Lưu</button>
              </form>

              
              <ul class="list-unstyled mb-2">
                <?php $__currentLoopData = $header->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="d-flex justify-content-between align-items-center small py-1">
                    <span><?php echo e($prod->name); ?></span>
                    <form
                      action="<?php echo e(route('admin.headers.product.remove', ['header'=>$header->id,'pid'=>$prod->id])); ?>"
                      method="POST"
                      style="margin:0;"
                    >
                      <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                      <button class="btn btn-sm btn-outline-danger">&times;</button>
                    </form>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($header->products->isEmpty()): ?>
                  <li class="text-muted small">Chưa có sản phẩm nào</li>
                <?php endif; ?>
              </ul>

              
              <form
                action="<?php echo e(route('admin.headers.product.add', $header)); ?>"
                method="POST"
                class="d-flex gap-2"
              >
                <?php echo csrf_field(); ?>
                <select name="product_id" class="form-select form-select-sm w-50">
                  <option value="">-- Chọn sản phẩm --</option>
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(! $header->products->contains($p->id)): ?>
                      <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="btn btn-primary btn-sm">+</button>
              </form>

              
              <form
                action="<?php echo e(route('admin.headers.destroy', $header)); ?>"
                method="POST"
                class="mt-2"
              >
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger btn-sm">Xóa Header</button>
              </form>

            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        
        <form action="<?php echo e(route('admin.headers.store')); ?>" method="POST" class="d-flex gap-2">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="category_id" value="<?php echo e($cat->id); ?>">
          <input
            type="text"
            name="title"
            class="form-control form-control-sm w-25"
            placeholder="Tiêu đề Header mới"
          >
          <button class="btn btn-primary btn-sm">Thêm Header</button>
        </form>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mimimain\resources\views/admin/headers/index.blade.php ENDPATH**/ ?>