<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <div class="row">
    <div class="col-md-6">
      <img src="<?php echo e($product->img); ?>" alt="<?php echo e($product->name); ?>" class="img-fluid mb-3">
    </div>
    <div class="col-md-6">
      <h1><?php echo e($product->name); ?></h1>
      <p><?php echo e($product->description); ?></p>
      <h4>Giá gốc: <?php echo e(number_format($product->base_price, 0, ',', '.')); ?>₫</h4>

      <form action="<?php echo e(route('cart.add', ['id' => $product->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $optionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="mb-3">
            <label for="option_<?php echo e($type->id); ?>" class="form-label"><?php echo e($type->name); ?></label>
            <select name="options[<?php echo e($type->id); ?>]" id="option_<?php echo e($type->id); ?>" class="form-select">
              <?php $__currentLoopData = $type->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($val->id); ?>" data-extra="<?php echo e($val->extra_price); ?>">
                  <?php echo e($val->value); ?> (+<?php echo e(number_format($val->extra_price, 0, ',', '.')); ?>₫)
                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button type="submit" class="btn btn-primary">Thêm vào giỏ hàng</button>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mimimain\resources\views/products/show.blade.php ENDPATH**/ ?>