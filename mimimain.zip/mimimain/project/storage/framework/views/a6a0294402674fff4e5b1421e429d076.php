<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <h2 class="mb-4">Tất cả sản phẩm</h2>
  <div class="row">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4 mb-3">
        <div class="card h-100">
          <img src="<?php echo e($product->img); ?>" class="card-img-top" alt="<?php echo e($product->name); ?>">
          <div class="card-body d-flex flex-column">
            <h5 class="card-title"><?php echo e($product->name); ?></h5>
            <p class="card-text"><?php echo e(Str::limit($product->description, 100)); ?></p>
            <p class="fw-bold"><?php echo e(number_format($product->base_price, 0, ',', '.')); ?>₫</p>
            <a href="<?php echo e(route('products.show', ['slug' => $product->slug])); ?>"
               class="btn btn-primary mt-auto">
              Xem chi tiết
            </a>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mimimain\resources\views/products/index.blade.php ENDPATH**/ ?>