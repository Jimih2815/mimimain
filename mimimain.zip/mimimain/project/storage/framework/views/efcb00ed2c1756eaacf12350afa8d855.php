<header>
  
  <div class="header-top d-flex align-items-center justify-content-between px-4 py-2">
    <a href="<?php echo e(route('home')); ?>" class="d-flex align-items-center">
      <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" height="50">
    </a>

    
    <form action="<?php echo e(route('products.index')); ?>" method="GET" class="input-group mx-4 flex-grow-1">
      <input
        type="text"
        name="q"
        class="form-control"
        placeholder="Tìm kiếm..."
        value="<?php echo e(request('q')); ?>"
      >
      <button class="btn btn-primary">
        <i class="bi bi-search"></i>
      </button>
    </form>

    
    <div class="d-flex align-items-center">
      <?php if(auth()->guard()->guest()): ?>
        <a href="<?php echo e(route('login')); ?>" class="btn btn-link text-decoration-none me-3">
          Đăng nhập
        </a>
        <?php if(Route::has('register')): ?>
          <a href="<?php echo e(route('register')); ?>" class="btn btn-link text-decoration-none me-3">
            Đăng ký
          </a>
        <?php endif; ?>
      <?php else: ?>
        <div class="dropdown me-3">
          <a
            href="#"
            class="text-dark dropdown-toggle"
            id="userDropdown"
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            <?php echo e(Auth::user()->name); ?>

          </a>
          <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
            <li>
              <a
                class="dropdown-item"
                href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();document.getElementById('logout-form').submit();"
              >
                Đăng xuất
              </a>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
              </form>
            </li>
          </ul>
        </div>
      <?php endif; ?>

      
      <?php
        $cart      = session('cart', []);
        $cartCount = array_sum(array_column($cart, 'quantity'));
      ?>
      <div class="dropdown">
        <a
          href="#"
          class="text-primary position-relative dropdown-toggle"
          id="cartDropdown"
          data-bs-toggle="dropdown"
          aria-expanded="false"
        >
          <i class="bi bi-cart-fill fs-4"></i>
          <?php if($cartCount > 0): ?>
            <span class="badge bg-danger position-absolute top-0 start-100 translate-middle p-1">
              <?php echo e($cartCount); ?>

            </span>
          <?php endif; ?>
        </a>
        <ul
          class="dropdown-menu dropdown-menu-end p-3"
          aria-labelledby="cartDropdown"
          style="min-width:300px; z-index:1200;"
        >
          <?php if(count($cart)): ?>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="d-flex align-items-center mb-2">
                <?php if($item['image']): ?>
                  <img src="<?php echo e($item['image']); ?>" width="50" class="me-2 rounded">
                <?php endif; ?>
                <div class="flex-grow-1">
                  <div class="fw-semibold"><?php echo e($item['name']); ?></div>
                  <small class="text-muted">
                    <?php echo e(number_format($item['price'],0,',','.')); ?>₫ × <?php echo e($item['quantity']); ?>

                  </small>
                </div>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li class="text-center mt-2">
              <a href="<?php echo e(route('cart.index')); ?>" class="btn btn-primary btn-sm w-100">
                Xem toàn bộ giỏ hàng
              </a>
            </li>
          <?php else: ?>
            <li class="text-center mb-0">Giỏ hàng trống! 😊</li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </div>

  
  <nav class="header-nav bg-light">
    <div class="container">
      <ul class="nav justify-content-center">
        <?php $__currentLoopData = $menuCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="nav-item dropdown position-static">
            <a class="nav-link" href="#" data-bs-toggle="dropdown"><?php echo e($cat->name); ?></a>
            <div class="dropdown-menu w-100 mega-menu p-4">
              <div class="container">
                
                <div class="row mb-3">
                  <?php $__currentLoopData = $cat->headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 text-center">
                      <button class="mega-header-box btn btn-outline-secondary w-100 py-3 mb-2">
                        <?php echo e($header->title); ?>

                      </button>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                <div class="row">
                  <?php $__currentLoopData = $cat->headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                      <ul class="list-unstyled mega-list">
                        <?php $__empty_1 = true; $__currentLoopData = $header->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <li>
                            <a href="<?php echo e(route('products.show',['slug'=>$prod->slug])); ?>">
                              <?php echo e($prod->name); ?>

                            </a>
                          </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <li><small class="text-muted">Chưa có SP</small></li>
                        <?php endif; ?>
                      </ul>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
            </div>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('products.index')); ?>">TẤT CẢ SẢN PHẨM</a>
        </li>
      </ul>
    </div>
  </nav>
</header>
<?php /**PATH C:\xampp\htdocs\mimimain\resources\views/partials/header.blade.php ENDPATH**/ ?>